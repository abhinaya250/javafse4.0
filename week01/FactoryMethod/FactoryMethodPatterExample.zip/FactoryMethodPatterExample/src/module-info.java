/**
 * 
 */
/**
 * 
 */
module FactoryMethodPatterExample {
}