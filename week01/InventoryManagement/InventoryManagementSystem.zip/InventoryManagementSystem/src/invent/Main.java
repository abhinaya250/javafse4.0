package invent;
import java.util.HashMap;
import java.util.Map;

class Product {
    int productId;
    String productName;
    int quantity;
    double price;

    public Product(int productId, String productName, int quantity, double price) {
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }

    public void display() {
        System.out.println("ID: " + productId + ", Name: " + productName + 
                           ", Qty: " + quantity + ", Price: $" + price);
    }
}


class Inventory {
    private Map<Integer, Product> productMap = new HashMap<>();

  
    public void addProduct(Product product) {
        productMap.put(product.productId, product);
        System.out.println("Product added: " + product.productName);
    }

   
    public void updateProduct(int productId, int quantity, double price) {
        Product product = productMap.get(productId);
        if (product != null) {
            product.quantity = quantity;
            product.price = price;
            System.out.println("Product updated: " + product.productName);
        } else {
            System.out.println("Product not found!");
        }
    }

    // Delete product
    public void deleteProduct(int productId) {
        if (productMap.containsKey(productId)) {
            Product removed = productMap.remove(productId);
            System.out.println("Deleted product: " + removed.productName);
        } else {
            System.out.println("Product not found!");
        }
    }

  
    public void displayInventory() {
        System.out.println("Inventory:");
        for (Product p : productMap.values()) {
            p.display();
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Inventory inv = new Inventory();

        Product p1 = new Product(101, "Mouse", 50, 299.99);
        Product p2 = new Product(102, "Keyboard", 30, 499.99);
        
        inv.addProduct(p1);
        inv.addProduct(p2);
        inv.displayInventory();

        inv.updateProduct(101, 60, 289.99);
        inv.displayInventory();

        inv.deleteProduct(102);
        inv.displayInventory();
    }
}
